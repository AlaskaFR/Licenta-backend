package com.example.licenta_backend2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicentaBackend2Application {
	public static void main(String[] args) {
		SpringApplication.run(LicentaBackend2Application.class, args);
	}
}
