package com.example.licenta_backend2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicentaBackend2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
